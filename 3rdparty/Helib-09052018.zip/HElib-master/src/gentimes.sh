./Test_matmul1D_x verbose=1 m=15709 L=10 g=27  2>&1
echo
echo "---------------"
echo
./Test_matmul1D_x verbose=1 m=5461 L=10 g=12  2>&1
echo
echo "---------------"
echo
./Test_matmul1D_x m=20801 verbose=1 L=10 g=5  2>&1
echo
echo "---------------"
echo
./Test_matmul1D_x verbose=1 m=10013 L=10 g=3  2>&1

